#####################################################################################################
##
## Data Science Examples Blog
## http://datascienceexamples.com
## 
## Example R script
##   Using NFL 2016 Season Game Data
##   Example - Using R Functions to compute NFL 2016 Season Game Data
## 
## 1. Create R working directory <<This example uses "C:\R" as R working directory
## 2. Get R example files from Github (https://github.com/mndatascienceexamples/datascienceexamples)
##    nfl_2016_games_allseason.txt
##    R_nflgames_example.R
##    R_nflgames_Functions.R
## 3. Copy R example files into working directory
## 4. Execute R_nflgames_example.R script or R commands individually.  
##    If "C:\R" is the R working directory with source files, then type the following commands at R prompt
##
##    R> setwd("C:\\R")
##    R> source("R_nflgames_Functions.R")
##    R> source("R_nflgames_example.R")
##
#####################################################################################################

## Load data from text file into R Data Frame (nflgame)
nflgames <- read.table("nfl_2016_games_allseason.txt", sep=",", header=TRUE, stringsAsFactors = TRUE)

## Load R Libraries
library(dplyr)

## Check Minnesota Vikings' Road Record

totalRoadWins(nflgames,"MIN")

totalRoadLosses(nflgames,"MIN")

totalRoadTies(nflgames,"MIN")

totalRoadGames(nflgames,"MIN")

roadTeamRecord(nflgames, "MIN") 

## Get list of all NFL team Road Game Records
allRoadTeamsRecords(nflgames)

## Check Minnesota Vikings' Home Record

totalHomeWins(nflgames,"MIN")

totalHomeLosses(nflgames,"MIN")

totalHomeTies(nflgames,"MIN")

totalHomeGames(nflgames,"MIN")

homeTeamRecord(nflgames, "MIN")

## Get list of all NFL team Home Game Records
allHomeTeamsRecords(nflgames)

## Check Minnesota Vikings' 2016 Season Record
nflTeamRecord(nflgames,"MIN")

## Check all team's 2016 Season Record
allTeamsRecord(nflgames)

## Check Minnesota Vikings' 2016 Road Games Points Scored
ptsScoredRoadGames(nflgames,"MIN")

## Get all road teams points scored
roadTeamsPtsScored(nflgames)

## Check Minnesota Vikings' 2016 Home Games Points Scored
ptsScoredHomeGames(nflgames,"MIN")

## Get all home teams points scored
homeTeamsPtsScored(nflgames)


## Check Minnesota Vikings' 2016 All Games Points Scored
ptsScoredAllGames(nflgames,"MIN")

## Get all teams points scored
allTeamsPtsScored(nflgames)


## Check Minnesota Vikings' 2016 Road Games Turnover Ratio
roadGamesTORatio(nflgames,"MIN")

## Get All Teams Road Games Turnover Ratio
roadTeamsTORatios(nflgames)

## Check Minnesota Vikings' 2016 Home Games Turnover Ratio
homeGamesTORatio(nflgames,"MIN")

## Get All Teams Home Games Turnover Ratio
homeTeamsTORatios(nflgames)

## Check Minnesota Vikings' 2016 All Games Turnover Ratio
teamTORatio(nflgames,"MIN")

## Get All Teams 2016 Games Turnover Ratio
allTeamsTORatio(nflgames)













