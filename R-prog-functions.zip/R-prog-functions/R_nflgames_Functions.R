#####################################################################################################
##
## Data Science Examples Blog
## http://datascienceexamples.com
## 
## Example R script
##   Using NFL 2016 Season Game Data
##   Example - Using R Functions to compute NFL 2016 Season Game Data
## 
## 1. Create R working directory <<This example uses "C:\R" as R working directory
## 2. Get R example files from Github (https://github.com/mndatascienceexamples/datascienceexamples)
##    nfl_2016_games_allseason.txt
##    R_nflgames_example.R
##    R_nflgames_Functions.R
## 3. Copy R example files into working directory
## 4. Execute R_nflgames_example.R script or R commands individually.  
##    If "C:\R" is the R working directory with source files, then type the following commands at R prompt
##
##    R> setwd("C:\\R")
##    R> source("R_nflgames_Functions.R")
##    R> source("R_nflgames_example.R")
##
#####################################################################################################


###ROAD_TEAM_RECORD
totalRoadGames <- function(nflgames, nflteam) {

  totalRoadGames <- subset(nflgames, (nflgames$roadTeam == nflteam))
  
  return(nrow(totalRoadGames))
}

totalRoadWins <- function(nflgames, nflteam) {
  totalRoadTeamWins <- subset(nflgames, (
	(nflgames$roadTeam == nflteam & (nflgames$rtTotalScore > nflgames$htTotalScore))
  ))
  return(nrow(totalRoadTeamWins))
}

totalRoadLosses <- function(nflgames, nflteam) {
  totalRoadTeamLosses <- subset(nflgames, (
	(nflgames$roadTeam == nflteam & (nflgames$rtTotalScore < nflgames$htTotalScore))
  ))
  return(nrow(totalRoadTeamLosses))
}

totalRoadTies <- function(nflgames, nflteam) {
  totalRoadTeamTies <- subset(nflgames, (
	(nflgames$roadTeam == nflteam & (nflgames$rtTotalScore == nflgames$htTotalScore) & (nflgames$otyn == 'Y'))
  ))
  return(nrow(totalRoadTeamTies))
}

roadTeamRecord <- function(nflgames, nflteam) {
  roadTeamRecord <- data.frame(matrix(ncol = 6))
  names(roadTeamRecord) <- c("team", "roadgames", "win", "loss", "otloss", "roadWinPct")
  roadTeamRecord[1,1] <- nflteam
  roadTeamRecord[1,2] <- totalRoadGames(nflgames, nflteam)
  roadTeamRecord[1,3] <- totalRoadWins(nflgames, nflteam)
  roadTeamRecord[1,4] <- totalRoadLosses(nflgames, nflteam)
  roadTeamRecord[1,5] <- totalRoadTies(nflgames, nflteam)
  roadTeamRecord[1,6] <- roadTeamRecord[3] / (roadTeamRecord[3] + roadTeamRecord[4] + roadTeamRecord[5])
  return(roadTeamRecord)
}

allRoadTeamsRecords <- function(nflgames) {
  roadTeamRecord <- data.frame(matrix(ncol = 6, nrow = 0))
  names(roadTeamRecord) <- c("team", "roadgames", "win", "loss", "otloss", "roadWinPct")
  teams <- distinct(nflgames,roadTeam)
  
  for (i in teams$roadTeam) {
    roadTeamRecord <- rbind(roadTeamRecord, roadTeamRecord(nflgames,i))
  }
  
  arrange(roadTeamRecord, desc(roadWinPct))
}

###HOME_TEAM_RECORD
totalHomeGames <- function(nflgames, nflteam) {

  totalHomeGames <- subset(nflgames, (nflgames$homeTeam == nflteam))
  
  return(nrow(totalHomeGames))
}

totalHomeWins <- function(nflgames, nflteam) {
  totalHomeTeamWins <- subset(nflgames, (
	(nflgames$homeTeam == nflteam & (nflgames$htTotalScore > nflgames$rtTotalScore))
  ))
  return(nrow(totalHomeTeamWins))
}

totalHomeLosses <- function(nflgames, nflteam) {
  totalHomeTeamLosses <- subset(nflgames, (
	(nflgames$homeTeam == nflteam & (nflgames$htTotalScore < nflgames$rtTotalScore))
  ))
  return(nrow(totalHomeTeamLosses))
}

totalHomeTies <- function(nflgames, nflteam) {
  totalHomeTeamTies <- subset(nflgames, (
	(nflgames$homeTeam == nflteam & (nflgames$htTotalScore == nflgames$rtTotalScore) & (nflgames$otyn == 'Y'))
  ))
  return(nrow(totalHomeTeamTies))
}

homeTeamRecord <- function(nflgames, nflteam) {
  homeTeamRecord <- data.frame(matrix(ncol = 6))
  names(homeTeamRecord) <- c("team", "homegames", "win", "loss", "otloss", "homeWinPct")
  homeTeamRecord[1,1] <- nflteam
  homeTeamRecord[1,2] <- totalHomeGames(nflgames, nflteam)
  homeTeamRecord[1,3] <- totalHomeWins(nflgames, nflteam)
  homeTeamRecord[1,4] <- totalHomeLosses(nflgames, nflteam)
  homeTeamRecord[1,5] <- totalHomeTies(nflgames, nflteam)
  homeTeamRecord[1,6] <- homeTeamRecord[3] / (homeTeamRecord[3] + homeTeamRecord[4] + homeTeamRecord[5])
  return(homeTeamRecord)
}

allHomeTeamsRecords <- function(nflgames) {
  homeTeamRecord <- data.frame(matrix(ncol = 6, nrow = 0))
  names(homeTeamRecord) <- c("team", "homegames", "win", "loss", "otloss", "homeWinPct")
  teams <- distinct(nflgames,homeTeam)
  
  for (i in teams$homeTeam) {
    homeTeamRecord <- rbind(homeTeamRecord, homeTeamRecord(nflgames,i))
  }
  
  arrange(homeTeamRecord, desc(homeWinPct))
}

###TEAM_RECORD(inLoc in varchar2 DEFAULT 'A');
nflTeamRecord <- function(nflgames, nflteam) {
  teamRecord <- data.frame(matrix(ncol = 6))
  names(teamRecord) <- c("team", "games", "win", "loss", "otloss", "winPct")
  teamRecord[1,1] <- nflteam
  teamRecord[1,2] <- totalRoadGames(nflgames, nflteam) + totalHomeGames(nflgames, nflteam)
  teamRecord[1,3] <- totalRoadWins(nflgames, nflteam) + totalHomeWins(nflgames, nflteam)
  teamRecord[1,4] <- totalRoadLosses(nflgames, nflteam) + totalHomeLosses(nflgames, nflteam)
  teamRecord[1,5] <- totalRoadTies(nflgames, nflteam) + totalHomeTies(nflgames, nflteam)
  teamRecord[1,6] <- teamRecord[3] / (teamRecord[3] + teamRecord[4] + teamRecord[5])
  return(teamRecord)
}

###ALL_TEAM_RECORD
allTeamsRecords <- function(nflgames) {
  teamRecord <- data.frame(matrix(ncol = 6, nrow = 0))
  names(teamRecord) <- c("team", "games", "win", "loss", "otloss", "winPct")
  teams <- distinct(nflgames,homeTeam)
  
  for (i in teams$homeTeam) {
    teamRecord <- rbind(teamRecord, nflTeamRecord(nflgames,i))
  }
  
  arrange(teamRecord, desc(winPct))
}



###ROAD_TEAM_POINTS_SCORED
ptsScoredRoadGames <- function(nflgames, nflteam) {

  teamRoadGames <- subset(nflgames, (nflgames$roadTeam == nflteam))
  
  roadTeamPts <- data.frame(matrix(ncol = 7, nrow = 0))
  names(roadTeamPts) <- c("RoadTeam", "RoadGamesPlayed", "RoadTotalPointsScored", "RoadAvgPointsScored", "RoadTotalPointsAllowed", "RoadAvgPointsAllowed", "RoadPtsDiff")

  roadTeamPts[1,1] <- nflteam
  roadTeamPts[1,2] <- totalRoadGames(nflgames, nflteam)
  roadTeamPts[1,3] <- sum(teamRoadGames$rtTotalScore)
  roadTeamPts[1,4] <- mean(teamRoadGames$rtTotalScore)
  roadTeamPts[1,5] <- sum(teamRoadGames$htTotalScore)
  roadTeamPts[1,6] <- mean(teamRoadGames$htTotalScore)
  roadTeamPts[1,7] <- sum(teamRoadGames$rtTotalScore) - sum(teamRoadGames$htTotalScore)
  return(roadTeamPts)

}

roadTeamsPtsScored <- function(nflgames) {
  roadTeamPts <- data.frame(matrix(ncol = 7, nrow = 0))
  names(roadTeamPts) <- c("RoadTeam", "RoadGamesPlayed", "RoadTotalPointsScored", "RoadAvgPointsScored", "RoadTotalPointsAllowed", "RoadAvgPointsAllowed", "RoadPtsDiff")
  teams <- distinct(nflgames,roadTeam)
  
  for (i in teams$roadTeam) {
    roadTeamPts <- rbind(roadTeamPts, ptsScoredRoadGames(nflgames,i))
  }
  
  arrange(roadTeamPts, desc(RoadTotalPointsScored))
}



###HOME_TEAM_POINTS_SCORED
ptsScoredHomeGames <- function(nflgames, nflteam) {

  teamHomeGames <- subset(nflgames, (nflgames$homeTeam == nflteam))
  
  homeTeamPts <- data.frame(matrix(ncol = 7, nrow = 0))
  names(homeTeamPts) <- c("HomeTeam", "HomeGamesPlayed", "HomeTotalPointsScored", "HomeAvgPointsScored", "HomeTotalPointsAllowed", "HomeAvgPointsAllowed", "HomePtsDiff")

  homeTeamPts[1,1] <- nflteam
  homeTeamPts[1,2] <- totalHomeGames(nflgames, nflteam)
  homeTeamPts[1,3] <- sum(teamHomeGames$htTotalScore)
  homeTeamPts[1,4] <- mean(teamHomeGames$htTotalScore)
  homeTeamPts[1,5] <- sum(teamHomeGames$rtTotalScore)
  homeTeamPts[1,6] <- mean(teamHomeGames$rtTotalScore)
  homeTeamPts[1,7] <- sum(teamHomeGames$htTotalScore) - sum(teamHomeGames$rtTotalScore)
  return(homeTeamPts)

}

homeTeamsPtsScored <- function(nflgames) {
  homeTeamPts <- data.frame(matrix(ncol = 7, nrow = 0))
  names(homeTeamPts) <- c("HomeTeam", "HomeGamesPlayed", "HomeTotalPointsScored", "HomeAvgPointsScored", "HomeTotalPointsAllowed", "HomeAvgPointsAllowed", "HomePtsDiff")
  
  teams <- distinct(nflgames,homeTeam)
  
  for (i in teams$homeTeam) {
    homeTeamPts <- rbind(homeTeamPts, ptsScoredHomeGames(nflgames,i))
  }
  
  arrange(homeTeamPts, desc(HomeTotalPointsScored))
}

###TEAM_POINTS_SCORED
ptsScoredAllGames <- function(nflgames, nflteam) {

  roadTeamGames <- ptsScoredRoadGames(nflgames, nflteam)
  homeTeamGames <- ptsScoredHomeGames(nflgames, nflteam)
  
  allTeamPts <- data.frame(matrix(ncol = 6, nrow = 0))
  names(allTeamPts) <- c("Team", "GamesPlayed", "TotalPointsScored", "AvgPointsScored", "TotalPointsAllowed", "AvgPointsAllowed")

  allTeamPts[1,1] <- nflteam
  allTeamPts[1,2] <- totalRoadGames(nflgames, nflteam) + totalHomeGames(nflgames, nflteam)
  allTeamPts[1,3] <- roadTeamGames$RoadTotalPointsScored + homeTeamGames$HomeTotalPointsScored
  allTeamPts[1,4] <- (roadTeamGames$RoadTotalPointsScored + homeTeamGames$HomeTotalPointsScored) / (roadTeamGames$RoadGamesPlayed + homeTeamGames$HomeGamesPlayed)
  allTeamPts[1,5] <- roadTeamGames$RoadTotalPointsAllowed + homeTeamGames$HomeTotalPointsAllowed
  allTeamPts[1,6] <- (roadTeamGames$RoadTotalPointsAllowed + homeTeamGames$HomeTotalPointsAllowed) / (roadTeamGames$RoadGamesPlayed + homeTeamGames$HomeGamesPlayed)
  return(allTeamPts)

}

###ALL_TEAM_POINTS_SCORED
allTeamsPtsScored <- function(nflgames) {
  allTeamPts <- data.frame(matrix(ncol = 7, nrow = 0))
  names(allTeamPts) <- c("Team", "GamesPlayed", "TotalPointsScored", "AvgPointsScored", "TotalPointsAllowed", "AvgPointsAllowed")
  
  teams <- distinct(nflgames,homeTeam)
  
  for (i in teams$homeTeam) {
    allTeamPts <- rbind(allTeamPts, ptsScoredAllGames(nflgames,i))
  }
  
  arrange(allTeamPts, desc(TotalPointsScored))
}



###ROAD_TEAM_TO_RATIO

roadGamesTORatio <- function(nflgames, nflteam) {

  teamRoadGames <- subset(nflgames, (nflgames$roadTeam == nflteam))
  
  roadTeamTOs <- data.frame(matrix(ncol = 7, nrow = 0))
  names(roadTeamTOs) <- c("RoadTeam", "RoadGamesPlayed", "RoadTotalForcedTOs", "RoadAvgForcedTOPerGame", "RoadTotalLostTOs", "RoadAvgLostTOPerGame", "RoadTODiff")

  roadTeamTOs[1,1] <- nflteam
  roadTeamTOs[1,2] <- totalRoadGames(nflgames, nflteam)
  roadTeamTOs[1,3] <- sum(teamRoadGames$htTO)
  roadTeamTOs[1,4] <- mean(teamRoadGames$htTO)
  roadTeamTOs[1,5] <- sum(teamRoadGames$rtTO)
  roadTeamTOs[1,6] <- mean(teamRoadGames$rtTO)
  roadTeamTOs[1,7] <- sum(teamRoadGames$htTO) - sum(teamRoadGames$rtTO)
  return(roadTeamTOs)

}

roadTeamsTORatios <- function(nflgames) {
  roadTeamTOs <- data.frame(matrix(ncol = 7, nrow = 0))
  names(roadTeamTOs) <- c("RoadTeam", "RoadGamesPlayed", "RoadTotalForcedTOs", "RoadAvgForcedTOPerGame", "RoadTotalLostTOs", "RoadAvgLostTOPerGame", "RoadTODiff")
  teams <- distinct(nflgames,roadTeam)
  
  for (i in teams$roadTeam) {
    roadTeamTOs <- rbind(roadTeamTOs, roadGamesTORatio(nflgames,i))
  }
  
  arrange(roadTeamTOs, desc(RoadTODiff))
}

###HOME_TEAM_BEST_TO_RATIO
homeGamesTORatio <- function(nflgames, nflteam) {

  teamHomeGames <- subset(nflgames, (nflgames$homeTeam == nflteam))
  
  homeTeamTOs <- data.frame(matrix(ncol = 7, nrow = 0))
  names(homeTeamTOs) <- c("HomeTeam", "HomeGamesPlayed", "HomeTotalForcedTOs", "HomeAvgForcedTOPerGame", "HomeTotalLostTOs", "HomeAvgLostTOPerGame", "HomeTODiff")

  homeTeamTOs[1,1] <- nflteam
  homeTeamTOs[1,2] <- totalHomeGames(nflgames, nflteam)
  homeTeamTOs[1,3] <- sum(teamHomeGames$rtTO)
  homeTeamTOs[1,4] <- mean(teamHomeGames$rtTO)
  homeTeamTOs[1,5] <- sum(teamHomeGames$htTO)
  homeTeamTOs[1,6] <- mean(teamHomeGames$htTO)
  homeTeamTOs[1,7] <- sum(teamHomeGames$rtTO) - sum(teamHomeGames$htTO)
  return(homeTeamTOs)

}

homeTeamsTORatios <- function(nflgames) {
  homeTeamTOs <- data.frame(matrix(ncol = 7, nrow = 0))
  names(homeTeamTOs) <- c("HomeTeam", "HomeGamesPlayed", "HomeTotalForcedTOs", "HomeAvgForcedTOPerGame", "HomeTotalLostTOs", "HomeAvgLostTOPerGame", "HomeTODiff")
  teams <- distinct(nflgames,homeTeam)
  
  for (i in teams$homeTeam) {
    homeTeamTOs <- rbind(homeTeamTOs, homeGamesTORatio(nflgames,i))
  }
  
  arrange(homeTeamTOs, desc(HomeTODiff))
}


###TEAM_TO_RATIO
teamTORatio <- function(nflgames, nflteam) {

  roadTeamGames <- roadGamesTORatio(nflgames, nflteam)
  homeTeamGames <- homeGamesTORatio(nflgames, nflteam)
  
  allTeamTORatio <- data.frame(matrix(ncol = 7, nrow = 0))
  names(allTeamTORatio) <- c("Team", "GamesPlayed", "TotalForcedTOs", "AvgForcedTOPerGame", "TotalLostTOs", "AvgLostTOPerGame", "TODiff")

  allTeamTORatio[1,1] <- nflteam
  allTeamTORatio[1,2] <- roadTeamGames$RoadGamesPlayed + homeTeamGames$HomeGamesPlayed
  allTeamTORatio[1,3] <- roadTeamGames$RoadTotalForcedTOs + homeTeamGames$HomeTotalForcedTOs
  allTeamTORatio[1,4] <- (roadTeamGames$RoadTotalForcedTOs + homeTeamGames$HomeTotalForcedTOs) / (roadTeamGames$RoadGamesPlayed + homeTeamGames$HomeGamesPlayed)
  allTeamTORatio[1,5] <- roadTeamGames$RoadTotalLostTOs + homeTeamGames$HomeTotalLostTOs
  allTeamTORatio[1,6] <- (roadTeamGames$RoadTotalLostTOs + homeTeamGames$HomeTotalLostTOs) / (roadTeamGames$RoadGamesPlayed + homeTeamGames$HomeGamesPlayed)
  allTeamTORatio[1,7] <- (roadTeamGames$RoadTotalForcedTOs + homeTeamGames$HomeTotalForcedTOs) - (roadTeamGames$RoadTotalLostTOs + homeTeamGames$HomeTotalLostTOs)
  return(allTeamTORatio)

}

###ALL_TEAM_BEST_TO_RATIO
allTeamsTORatio <- function(nflgames) {
  allTeamsTO <- data.frame(matrix(ncol = 7, nrow = 0))
  names(allTeamsTO) <- c("Team", "GamesPlayed", "TotalForcedTOs", "AvgForcedTOPerGame", "TotalLostTOs", "AvgLostTOPerGame", "TODiff")
  
  teams <- distinct(nflgames,homeTeam)
  
  for (i in teams$homeTeam) {
    allTeamsTO <- rbind(allTeamsTO, teamTORatio(nflgames,i))
  }
  
  arrange(allTeamsTO, desc(TODiff))
}


































